<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="contenido_login">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img class="logo" src="images/logo/logo.png">
                    </div>
                    <h2 class="fw-bold instituto">INSTITUTO DE EDUCACION SUPERIOR TECNOLOGICO PUBLICO DE NUÑOA</h2>
                    <!-- Login-->
                    <form action=""  method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <input type="email" class="form-control" id="email" name="email" placeholder="Usuario" required>
                        </div>
                        <div class="mb-4">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña" required>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p>* <?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-grid">

                            <button type="submit" class="boton_inicio"> <i class="fa fa-sign-in fa-1g" aria-hidden="true"></i>Iniciar Sesión</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn1\iestpn\resources\views/auth/login.blade.php ENDPATH**/ ?>