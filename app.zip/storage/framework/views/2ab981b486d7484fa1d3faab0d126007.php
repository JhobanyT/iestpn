<?php $__env->startSection('title', 'Programas de Estudio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end">
        <a href="programaEstudios/create" class="btn btn-agregar"><i class="fa fa-plus" aria-hidden="true"></i> CREAR</a>
    </div>
    <div class="card-body">
        <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">
            <table id="example1" class="table mt-4 table-hover" role="grid" aria-describedby="example1_info">
                <thead>
                    <tr role="row">
                        <th class="text-center">Nombre</th>
                        <th class="text-center">Opciones</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $programaEstudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pestudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd">
                        <td><?php echo e($pestudio->nombre); ?></td>
                        <td class="">
                            <form class="d-flex justify-content-around formulario_eliminar" action="<?php echo e(route ('programaEstudios.destroy',$pestudio->id)); ?>" method="POST">
                                <a class="btn btn-info" href="/programaEstudios/<?php echo e($pestudio->id); ?>/edit"><i class="fa fa-pencil" aria-hidden="true"></i> Editar</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i> Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<script>
// Verificar si existe el mensaje de éxito
$(document).ready(function() {
    <?php if(Session::has('success')): ?>
        toastr.options = {
            "positionClass": "toast-bottom-right",
        };
        toastr.success("<?php echo e(Session::get('success')); ?>");
    <?php endif; ?>
});
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/programaEstudios/index.blade.php ENDPATH**/ ?>