<?php $__env->startSection('title', 'Editar Programa De Estudio'); ?>

<?php $__env->startSection('content'); ?>
    <form action="/programaEstudios/<?php echo e($pestudio->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input placeholder="Marketing" type="text" id="nombre" name="nombre" class="form-control" value="<?php echo e($pestudio->nombre); ?>" required>
        </div>
        <a href="<?php echo e(url('programaEstudios')); ?>" class="btn btn-warning" tabindex="2"><i class="fas fa-backspace"></i> Cancelar</a>
        <button type="submit" class="btn btn-success"><i class="fas fa-file-download"></i> Guardar</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn1\iestpn\resources\views/programaEstudios/edit.blade.php ENDPATH**/ ?>