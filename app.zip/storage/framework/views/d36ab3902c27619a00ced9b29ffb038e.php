<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<link rel="icon" href="<?php echo e(asset('images/logo/logo.png')); ?>">
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
		<link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">

		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

	</head>
    <body>
	<div class="sidebar" id="sidebar">
		<div class="logo">
			<img src="<?php echo e(asset('images/logo/logo.png')); ?>" alt="Logo">
		</div>
		<div class="logo-nombre mt-3">
			<p class="company-name">INSTITUTO DE EDUCACION SUPERIOR TECNOLOGICO PUBLICO DE NUÑOA</p>
		</div>
			<ul class="nav">
				<li class="nav-item active">
					<a href="<?php echo e(url('trabajoAplicacion')); ?>">
						<i class="fa fa-files-o"></i>
						<span class="nav-text">Trabajos de Aplicación</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="#">
						<i class="fa fa-book"></i>
						<span class="nav-text">Programa de Estudios</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="#">
						<i class="fa fa-users"></i>
						<span class="nav-text">Usuarios</span>
					</a>
				</li>
			</ul>

		<div class="logout-btn">
			<div class="logout-btn-wrapper">
				<button><i class="fa fa-sign-out" aria-hidden="true"></i><a href="<?php echo e(route('login.destroy')); ?>">Cerrar Sesión</a></button>
			</div>
		</div>
	</div>
	<div class="content">
		<header>
			<div class="header-left">
				<div class="toggle-sidebar-btn" id="toggleSidebarBtn">
					<i class="fa fa-bars fa-2x" aria-hidden="true"></i>
				</div>
			</div>
			<div class="header-right">
				<div class="profile">
					<img src="<?php echo e(asset('images/logo/logo.png')); ?>" alt="Avatar">
					<p><?php echo e(auth()->user()->name); ?><span><?php echo e(auth()->user()->role); ?></span></p>
				</div>
			</div>
		</header>
		<div class="border-dark border-bottom mb-2">
			<a href="<?php echo e(route('changeme.showChangePasswordForm')); ?>" class="btn btn-dark">Cambiar Contraseña</a>
			<a href="<?php echo e(route('register.index')); ?>" class="btn btn-info" class="icon-a"><i class="fa fa-users icons"></i><p class="letra_icon d-inline"> Registrar Usuario </p></a>
			<h4>
				<?php echo $__env->yieldContent('title'); ?>
			</h4>
		</div>
		<main>
			<div> 
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</main>
	</div>

<script>
	const toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
	const sidebar = document.getElementById('sidebar');
	const content = document.querySelector('.content');

	// Función para minimizar el sidebar
	function minimizeSidebar() {
	sidebar.classList.add('sidebar-closed');
	content.classList.add('content-closed');
	}

	// Función para maximizar el sidebar
	function maximizeSidebar() {
	sidebar.classList.remove('sidebar-closed');
	content.classList.remove('content-closed');
	}

	// Listener para el botón de toggle
	toggleSidebarBtn.addEventListener('click', () => {
	if (sidebar.classList.contains('sidebar-closed')) {
		maximizeSidebar();
	} else {
		minimizeSidebar();
	}
	});

	// Listener para detectar el cambio de tamaño de pantalla
	window.addEventListener('resize', () => {
	if (window.innerWidth <= 600) {
		minimizeSidebar();
	} else {
		maximizeSidebar();
	}
	});

	if (window.innerWidth <= 600) {
	minimizeSidebar();
	}
</script>
</body>
        
	
</html><?php /**PATH C:\xampp\htdocs\iestpn1\iestpn\resources\views/layout/template.blade.php ENDPATH**/ ?>