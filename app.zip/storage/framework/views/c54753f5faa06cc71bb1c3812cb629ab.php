<?php $__env->startSection('title', 'Crear Programa de Estudio'); ?>

<?php $__env->startSection('content'); ?>

<!-- <?php if($errors->any()): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?> -->

<form action="<?php echo e(url('programaEstudios')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input placeholder="Marketing" type="text" id="nombre" name="nombre" class="form-control" required>
    </div>
    <a href="<?php echo e(url('programaEstudios')); ?>" class="btn btn-warning" tabindex="3"><i class="fas fa-backspace"></i>
        Cancelar</a>
    <button type="submit" class="btn btn-success" tabindex="4"><i class="fas fa-file-download"></i> Guardar</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn1\iestpn\resources\views/programaEstudios/create.blade.php ENDPATH**/ ?>