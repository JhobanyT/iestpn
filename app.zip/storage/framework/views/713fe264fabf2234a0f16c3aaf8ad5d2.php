<?php $__env->startSection('title', 'Trabajos de Aplicación'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-3">
    <a href="<?php echo e(route('trabajoAplicacion.create')); ?>" class="btn btn-agregar">
        <i class="fa fa-plus" aria-hidden="true"></i> CREAR
    </a>
</div>
<div class="container">
    <div class="row">
        <!-- Div de la derecha -->
        <div class="col-md-2 order-md-2">
            <div class="row">
                <div class="col-12">
                    <h4>Listar</h4>
                    <div class="row">
                        <div class="col-12">
                            <button class="btn btn-block w-100">Año de publicación</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button class="btn btn-block w-100">Autores</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button class="btn btn-block w-100">Títulos</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <h4>Filtros</h4>
                    <div class="row">
                        <div class="col-12">
                            <button class="btn btn-block w-100">Año de publicación</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-10 order-md-1">
            <h4>Repositorio institucional de trabajos de Aplicación de la IESTPN</h4>
            <form action="<?php echo e(route('trabajoAplicacion.index')); ?>" method="GET">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Buscar..." name="q">
                    <div class="col-md-3">
                        <input type="date" class="form-control" name="fecha">
                    </div>
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </form>
            <?php if($searchTerm || $fecha): ?>
                <p>
                    Resultados de búsqueda de:
                    <!-- Mostrar término de búsqueda -->
                    <?php if($searchTerm): ?>
                        <strong><?php echo e($searchTerm); ?></strong>
                    <?php endif; ?>

                    <!-- Mostrar fecha de búsqueda -->
                    <?php if($fecha): ?>
                        <?php if($searchTerm): ?> y <?php endif; ?>
                        <strong><?php echo e($fecha); ?></strong>
                    <?php endif; ?>
                    <a href="<?php echo e(route('trabajoAplicacion.index')); ?>">
                        <i class="fa fa-times" style="color: red;" aria-hidden="true"></i>
                    </a>
                </p>
            <?php endif; ?>

            <?php
                $showMore = isset($_GET['show_more']) && $_GET['show_more'] === 'true';
            ?>
            <?php $__currentLoopData = $trabajoAplicacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-xl-2 previwe-pdf">
                        <div class="archivo-preview" style="overflow: hidden">
                            <div style="margin-right: -16px;">
                                <iframe id="pdfIframe" src="<?php echo e(asset('storage/archivos/' . basename($trabajo->archivo))); ?>" type="application/pdf" style="display: block; overflow: hidden scroll; height: 160px; width: 100%; pointer-events: none;" frameborder="0" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                    <div class="trabajo-item col-md-12 col-lg-12 col-xl-10 d-md-block">
                        <h5><a class="a-titulo" href="<?php echo e(route('trabajoAplicacion.show', ['trabajoAplicacion' => $trabajo->id])); ?>">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->titulo); ?>

                        </a></h5>
                        <?php
                            $autores = $trabajo->autores->pluck('nombre')->toArray();
                            $institucion = 'INSTITUTO DE EDUCACION SUPERIOR TECNOLOGICO PUBLICO DE NUÑOA';
                            $fechaPublicacion = date('Y-m-d', strtotime($trabajo->created_at));
                        ?>
                        <p class="p-autor">
                            <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $autor); ?><?php echo e(!$loop->last ? '; ' : ''); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            (<?php echo e($institucion); ?>, <?php echo e($fechaPublicacion); ?>)
                        </p>
                        <p class="p-tipo">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->tipo); ?> -> <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->programaEstudiosMasComun); ?>

                        </p>
                        <p class="p-resumen">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', substr($trabajo->resumen, 0, 300)); ?>...
                        </p>
                        <hr>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($trabajoAplicacion->isEmpty()): ?>
                <p>No se encontraron resultados para la búsqueda.</p>
            <?php endif; ?>
            <div class="pagination-buttons">
                <div class="float-start">
                    <?php if($trabajoAplicacion->currentPage() > 1): ?>
                        <a href="<?php echo e($trabajoAplicacion->previousPageUrl()); ?>" class="dark-button"><i class="fa fa-chevron-left" aria-hidden="true"></i></a>
                    <?php endif; ?>
                </div>
                <div class="text-center">
                    <?php if($trabajoAplicacion->count() > 1): ?>
                        Mostrando ítems <?php echo e($trabajoAplicacion->firstItem()); ?>-<?php echo e($trabajoAplicacion->lastItem()); ?> de <?php echo e($trabajoAplicacion->total()); ?>

                    <?php else: ?>
                        Mostrando ítem <?php echo e($trabajoAplicacion->firstItem()); ?> de <?php echo e($trabajoAplicacion->total()); ?>

                    <?php endif; ?>
                </div>
                <div class="float-end">
                    <?php if($trabajoAplicacion->hasMorePages()): ?>
                        <a href="<?php echo e($trabajoAplicacion->nextPageUrl()); ?>" class="dark-button"><i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/taplicacion.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/trabajoaplicacion/index.blade.php ENDPATH**/ ?>