

<?php $__env->startSection('title', 'Editar usuario'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <form action="<?php echo e(route('usuarios.update', $users->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
          <div class="col-md-12">
            <div class="form-group mb-2">
              <label for="name" class="form-label">Nombre:</label>
              <input type="text" class="form-control" name="name" id="name" value="<?php echo e($users->name); ?>">
            </div>
            <div class="form-group mb-2">
              <label for="email" class="form-label">Correo:</label>
              <input type="text" class="form-control" name="email" id="email" value="<?php echo e($users->email); ?>">
            </div>
            <div class="form-group mb-2">
                <label for="role" class="form-label">Rol:</label>
                <select class="form-select" name="role" id="role">
                    <option value="estudiante" <?php echo e($users->role === 'estudiante' ? 'selected' : ''); ?>>Estudiante</option>
                    <option value="admin" <?php echo e($users->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                </select>
            </div>
            <div class="col-md-12 col-12 mb-2 d-flex align-items-end justify-content-end">
              <a href="<?php echo e(route('usuarios.show', $users->id)); ?>" class="btn btn-warning btn-cancel"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> Cancelar</a>
              <button type="submit" class="btn btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/user/edit.blade.php ENDPATH**/ ?>