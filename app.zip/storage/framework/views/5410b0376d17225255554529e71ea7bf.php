<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Div de la derecha -->
        <div class="col-md-2 order-md-2">
            <div class="row">
                <div class="col-12">
                    <h4>Listar</h4>
                    <div class="row">
                        <div class="col-12">
                            <form action="<?php echo e(route('publics.index')); ?>" method="GET" class="d-inline">
                                <button type="submit" class="btn btn-block w-100 <?php echo e(!$filtroAnio ? 'btn-dark' : 'btn-light'); ?>">
                                    Todos
                                </button>
                            </form>
                            <?php $__currentLoopData = $availableYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(route('publics.index')); ?>" method="GET" class="d-inline">
                                    <input type="hidden" name="anio" value="<?php echo e($year); ?>">
                                    <button type="submit" class="btn btn-block w-100 <?php echo e($filtroAnio == $year ? 'btn-dark' : 'btn-light'); ?>">
                                        <?php echo e($year); ?>

                                    </button>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <h4>Filtros</h4>
                    <div class="row">
                        <div class="col-12">
                            <form action="<?php echo e(route('publics.index')); ?>" method="GET" id="filtroForm">
                                <div class="input-group mb-3">
                                    <div>
                                        <label style="margin-right: 10px;">
                                            <input type="checkbox" name="pestudio[]" value="Computación e Informática" <?php echo e(in_array('Computación e Informática', $selectedPestudios) ? 'checked' : ''); ?>>
                                            Computación e Informática
                                        </label>
                                    </div>
                                    <div>
                                        <label style="margin-right: 10px;">
                                            <input type="checkbox" name="pestudio[]" value="Contabilidad" <?php echo e(in_array('Contabilidad', $selectedPestudios) ? 'checked' : ''); ?>>
                                            Contabilidad
                                        </label>
                                    </div>
                                    <div>
                                        <label style="margin-right: 10px;">
                                            <input type="checkbox" name="tipo[]" value="Interdisciplinario" <?php echo e(in_array('Interdisciplinario', $selectedTipos) ? 'checked' : ''); ?>>
                                            Interdisciplinario
                                        </label>
                                    </div>
                                    <div>
                                        <label style="margin-right: 10px;">
                                            <input type="checkbox" name="tipo[]" value="Normal" <?php echo e(in_array('Normal', $selectedTipos) ? 'checked' : ''); ?>>
                                            Normal
                                        </label>
                                    </div>
                                    <br>
                                    <div style="display: block; margin-bottom: 10px; width: 100%;">
                                        <button class="btn btn-primary" type="submit">Ejecutar Filtro</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-10 order-md-1">
            <h4 class="mb-3">Repositorio institucional de trabajos de Aplicación de la IESTPN</h4>
            <form action="<?php echo e(route('publics.index')); ?>" method="GET">
                <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Buscar..." name="q" value="<?php echo e($searchTerm); ?>">
                    <div class="col-md-3">
                        <input type="date" class="form-control" name="fecha" value="<?php echo e($fecha); ?>">
                    </div>
                    <input type="hidden" name="anio" value="<?php echo e($filtroAnio); ?>">
                    <?php $__currentLoopData = $selectedPestudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="pestudio[]" value="<?php echo e($selected); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $selectedTipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="tipo[]" value="<?php echo e($selected); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </form>
            <?php if($searchTerm || $fecha || $filtroAnio ||  !empty($selectedPestudios) || !empty($selectedTipos)): ?>
            <p>
                Resultados de búsqueda de:
                <?php if($filtroAnio): ?>
                    <strong>Año: <?php echo e($filtroAnio); ?></strong>
                <?php endif; ?>
                <!-- Mostrar término de búsqueda -->
                <?php if($searchTerm): ?>
                    <?php if($filtroAnio): ?> y <?php endif; ?>
                    <strong>Término: <?php echo e($searchTerm); ?></strong>
                <?php endif; ?>

                <?php if(!empty($selectedPestudios)): ?>
                    <?php if($filtroAnio || $searchTerm): ?> y <?php endif; ?>
                    <strong>Programa de Estudios: <?php echo e(implode(', ', $selectedPestudios)); ?></strong>
                <?php endif; ?>

                <?php if(!empty($selectedTipos)): ?>
                    <?php if($filtroAnio || $searchTerm || !empty($selectedPestudios)): ?> y <?php endif; ?>
                    <strong>Tipo: <?php echo e(implode(', ', $selectedTipos)); ?></strong>
                <?php endif; ?>

                <!-- Mostrar fecha de búsqueda -->
                <?php if($fecha): ?>
                    <?php if($filtroAnio || $searchTerm || !empty($selectedPestudios) || !empty($selectedTipos)): ?> y <?php endif; ?>
                    <strong>Fecha: <?php echo e($fecha); ?></strong>
                <?php endif; ?>
                <?php if($filtroAnio || $searchTerm || !empty($selectedPestudios) || !empty($selectedTipos) || $fecha): ?>
                    <a href="<?php echo e(route('publics.index')); ?>">
                        <i class="fa fa-times" style="color: red;" aria-hidden="true"></i>
                    </a>
                <?php endif; ?>
            </p>
            <?php endif; ?>
            <h6 class="mb-3">Añadido Recientemente</h6>
            <?php
                $showMore = isset($_GET['show_more']) && $_GET['show_more'] === 'true';
            ?>
            <?php $__currentLoopData = $trabajoAplicacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-xl-2 previwe-pdf">
                        <div class="archivo-preview" style="overflow: hidden">
                            <div style="margin-right: -16px;">
                                <iframe id="pdfIframe" src="<?php echo e(asset('storage/archivos/' . basename($trabajo->archivo))); ?>" type="application/pdf" style="display: block; overflow: hidden scroll; height: 160px; width: 100%; pointer-events: none;" frameborder="0" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                    <div class="trabajo-item col-md-12 col-lg-12 col-xl-10 d-md-block">
                    <h5><a class="a-titulo" href="<?php echo e(route('publics.show', ['id' => $trabajo->id])); ?>">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->titulo); ?>

                        </a></h5>
                        <?php
                            $autores = $trabajo->autores->pluck('nombre')->toArray();
                            $institucion = 'INSTITUTO DE EDUCACION SUPERIOR TECNOLOGICO PUBLICO DE NUÑOA';
                            $fechaPublicacion = date('Y-m-d', strtotime($trabajo->created_at));
                        ?>
                        <p class="p-autor">
                            <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $autor); ?><?php echo e(!$loop->last ? '; ' : ''); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            (<?php echo e($institucion); ?>, <?php echo e($fechaPublicacion); ?>)
                        </p>
                        <p class="p-tipo">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->tipo); ?> -> <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', $trabajo->programaEstudiosMasComun); ?>

                        </p>
                        <p class="p-resumen">
                            <?php echo str_replace($searchTerm, '<mark>'.$searchTerm.'</mark>', substr($trabajo->resumen, 0, 300)); ?>...
                        </p>
                        <hr>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($trabajoAplicacion->isEmpty()): ?>
                <p>No se encontraron resultados para la búsqueda.</p>
            <?php endif; ?>
            <div class="pagination-buttons">
                <div class="float-start">
                    <?php if($trabajoAplicacion->currentPage() > 1): ?>
                        <a href="<?php echo e($trabajoAplicacion->previousPageUrl()); ?>" class="dark-button" id="back-icon"><i class="fa fa-chevron-left" aria-hidden="true"></i></a>
                    <?php endif; ?>
                </div>
                <div class="text-center">
                    <?php if($trabajoAplicacion->count() > 1): ?>
                        Mostrando ítems <?php echo e($trabajoAplicacion->firstItem()); ?>-<?php echo e($trabajoAplicacion->lastItem()); ?> de <?php echo e($trabajoAplicacion->total()); ?>

                    <?php else: ?>
                        Mostrando ítem <?php echo e($trabajoAplicacion->firstItem()); ?> de <?php echo e($trabajoAplicacion->total()); ?>

                    <?php endif; ?>
                </div>
                <div class="float-end">
                    <?php if($trabajoAplicacion->hasMorePages()): ?>
                        <a href="<?php echo e($trabajoAplicacion->nextPageUrl()); ?>" class="dark-button" id="next-icon"><i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Obtenemos el elemento del botón con el icono de flecha hacia la izquierda
        const backIcon = document.getElementById('back-icon');

        // Verificar si el elemento existe antes de ocultarlo
        if (backIcon !== null) {
            // Ocultar el botón de "back" si no hay más páginas anteriores
            if (!<?php echo e($trabajoAplicacion->onFirstPage()); ?>) {
                backIcon.style.display = 'none';
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/templatep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/publics/index.blade.php ENDPATH**/ ?>