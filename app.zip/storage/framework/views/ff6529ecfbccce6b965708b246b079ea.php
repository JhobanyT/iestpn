<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bienvenido a la aplicación</h1>
    <a href="<?php echo e(route('login.destroy')); ?>"> Cerrar Sesión</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/home.blade.php ENDPATH**/ ?>