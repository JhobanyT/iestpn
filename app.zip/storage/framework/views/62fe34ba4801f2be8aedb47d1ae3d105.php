<?php $__env->startSection('title', 'Crear Programa de Estudio'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(url('programaEstudios')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input placeholder="Marketing" type="text" id="nombre" name="nombre" class="form-control" required>
    </div>
    <a href="<?php echo e(url('programaEstudios')); ?>" class="btn btn-warning" tabindex="3"><i class="fas fa-backspace"></i>
        Cancelar</a>
    <button type="submit" class="btn btn-success" tabindex="4"><i class="fas fa-file-download"></i> Guardar</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\iestpn\resources\views/programaEstudios/create.blade.php ENDPATH**/ ?>